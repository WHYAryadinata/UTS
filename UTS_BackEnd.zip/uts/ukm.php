<?php
include 'configukm.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UTS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

  <link rel="stylesheet" href="uts.css">
</head>
<style>
</style>

<body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="ht.png" alt="" width="75px">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active text-center" aria-current="page" href="http://localhost/UTS/home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-center" href="http://localhost/UTS/index.php">Mahasiswa</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-center" href="http://localhost/UTS/organisasi.php">Organisasi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-center" href="#">UKM</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-center" href="http://localhost/UTS/asdos.php">Asdos</a>
          </li>

        </ul>
      </div>
    </div>
  </nav>
  <form method="POST" action="prosesukm.php">
    <legend>
      <center>Form Pendaftaran UKM</center>
    </legend>
    <table>
      <tr>
        <td><label for="nama" class="form-label">Nama</label></td>
        <td><input type="text" id="nama" name="nama" class="form-control"></td>
      </tr>
      <tr>
        <td><label for="nim" class="form-label">NIM</label></td>
        <td><input type="text" id="nim" name="nim" class="form-control"></td>
      </tr>
      <tr>
        <td>Jurusan</td>
        <td><select name="jurusan">
            <option value="001">Sistem Komputer</option>
            <option value="002">Sistem Informasi</option>
            <option value="003">Teknologi Informasi</option>
          </select></td>
      </tr>
      <tr>
        <td><label class="form-label">Angkatan</label></td>
        <td><input type="text" name="angkatan" class="form-control"></td>
      </tr>
      <tr>
        <td>Gender</td>
        <td>
          <input type="radio" name="gender" value="laki-laki">Laki-laki
          <input type="radio" name="gender" value="perempuan">Perempuan
        </td>
      </tr>
      <tr>
        <td>UKM yang dipilih</td>
        <td>
          <select name="ukm">
            <option value="Paskibra">Paskibra</option>
            <option value="PMR">PMR</option>
            <option value="Basket">Basket</option>
            <option value="Voli">Voli</option>
          </select>
        </td>
      </tr>
      <tr>
        <td><label for="keahlian" class="form-label">Keahlian yang Dikuasai</label></td>
        <td><input type="text" id="keahlian" name="keahlian" class="form-control"></td>
      </tr>
      <tr>
        <td><label class="form-label">No Hp</label></td>
        <td><input type="text" name="no_hp" class="form-control"></td>
      </tr>
      <tr>
        <td><label class="form-label">Email</label></td>
        <td><input type="email" name="email" class="form-control"></td>
      </tr>
      <tr>
        <td><input type="submit" value="Simpan"><input type="button" value="Kembali"></td>
      </tr>
    </table>
  </form>

  <table style="margin-top: 20px;">
    <tr style="border: 1px solid black;">
      <th style="border: 1px solid black;">NO </th>
      <th style="border: 1px solid black;">Nama</th>
      <th style="border: 1px solid black;">NIM</th>
      <th style="border: 1px solid black;">Jurusan</th>
      <th style="border: 1px solid black;">Angkatan</th>
      <th style="border: 1px solid black;">Gender</th>
      <th style="border: 1px solid black;">UKM yang dipilih</th>
      <th style="border: 1px solid black;">Keahlian yang dikuasai</th>
      <th style="border: 1px solid black;">No HP</th>
      <th style="border: 1px solid black;">Email</th>
      <th style="border: 1px solid black;">Action</th>
    </tr>
    <?php
    $no = 1;
    while ($d = mysqli_fetch_assoc($data)) {
    ?>
      <tr style="border: 1px solid black;">
        <td style="border: 1px solid black;"><?= $no++; ?></td>
        <td style="border: 1px solid black;"><?= $d["nama"]; ?></td>
        <td style="border: 1px solid black;"><?= $d["nim"]; ?></td>
        <td style="border: 1px solid black;"><?= $d['kd_jurusan']; ?></td>
        <td style="border: 1px solid black;"><?= $d['angkatan']; ?></td>
        <td style="border: 1px solid black;"><?= $d['gender'] == 1 ? 'Laki-Laki' : 'Perempuan'; ?></td>
        <td style="border: 1px solid black;"><?= $d['ukm']; ?></td>
        <td style="border: 1px solid black;"><?= $d['keahlian']; ?></td>
        <td style="border: 1px solid black;"><?= $d['no_hp']; ?></td>
        <td style="border: 1px solid black;"><?= $d['email']; ?></td>
        <td style="border: 1px solid black;">
          <a href="editukm.php?nim=<?= $d["nim"] ?>">Edit</a>
          <a href="deleteukm.php?nim=<?= $d["nim"] ?>" onclick="return confirm('Apakah anda yakin menghapus data ini ?');">Hapus</a>
        </td>
      </tr>
    <?php
    }
    ?>
  </table>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>