<?php

include 'configorganisasi.php';

$nama = $_POST ['nama'];
$nim = $_POST ['nim'];
$kd_jurusan = $_POST ['jurusan'];
$angkatan = $_POST ['angkatan'];
$gender = $_POST ['gender'];
$organisasi = $_POST ['organisasi'];
$keahlian = $_POST ['keahlian'];
$no_hp = $_POST ['no_hp'];
$email = $_POST ['email'];

$sql = "INSERT INTO organisasi (nama,nim,kd_jurusan,angkatan,gender,organisasi,keahlian,no_hp,email) 
VALUES ('$nama','$nim','$kd_jurusan', '$angkatan', '$gender','$organisasi', '$keahlian', '$no_hp','$email' )";

    if(mysqli_query($conn, $sql)){
        $message = "Data Berhasil Dimasukan";
        echo "<script type='text/javascript'>window.alert('$message'); window.location = 'organisasi.php';</script>";
    }
    else{
        $message = "Data Berhasil Dimasukan";
        echo "<script type='text/javascript'>window.alert('$message'); window.location = 'organisasi.php';</script>";
    }
    mysqli_close($conn);
?>