<?php

include 'configasdos.php';

$nama = $_POST ['nama'];
$nim = $_POST ['nim'];
$kd_jurusan = $_POST ['jurusan'];
$angkatan = $_POST ['angkatan'];
$gender = $_POST ['gender'];
$dosen = $_POST ['dosen'];
$keahlian = $_POST ['keahlian'];
$no_hp = $_POST ['no_hp'];
$email = $_POST ['email'];

$sql = "INSERT INTO asdos (nama,nim,kd_jurusan,angkatan,gender,dosen,keahlian,no_hp,email) 
VALUES ('$nama','$nim','$kd_jurusan', '$angkatan', '$gender','$dosen', '$keahlian', '$no_hp','$email' )";

    if(mysqli_query($conn, $sql)){
        $message = "Data Berhasil Dimasukan";
        echo "<script type='text/javascript'>window.alert('$message'); window.location = 'asdos.php';</script>";
    }
    else{
        $message = "Data Berhasil Dimasukan";
        echo "<script type='text/javascript'>window.alert('$message'); window.location = 'asdos.php';</script>";
    }
    mysqli_close($conn);
?>