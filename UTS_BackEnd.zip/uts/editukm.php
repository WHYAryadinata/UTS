<?php 
    include 'configukm.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTS</title>
</head>
<style>
</style>
<body>
    <?php 
        $nim = $_GET['nim'];
        $data = mysqli_query($conn,"SELECT * FROM ukm WHERE nim = '$nim' ");
        while($d = mysqli_fetch_assoc($data)){
        ?> 
        	<form method="POST" action="updateukm.php">
		<table>
		<tr>
				<td><label for="nama">Nama:</label></td>
				<td><input type="text" id="nama" name="nama" value="<?= $d["nama"];?>"></td>
			</tr>
			<tr>
				<td><label for="nim">NIM:</label></td>
				<td><input type="text" id="nim" name="nim" value="<?= $d["nim"];?>"></td>
			</tr>
			<tr>
                    <td>Jurusan</td>
                    <td><select name="jurusan" value="<?= $d["jurusan"];?>">
                        <option value="001">Sistem Komputer</option>
                        <option value="002">Sistem Informasi</option>
                        <option value="003">Teknologi Informasi</option>
                    </select></td>
                </tr>
			<tr>
				<td><label for="angkatan">Angkatan:</label></td>
				<td><input type="text" id="angkatan" name="angkatan" value="<?= $d["angkatan"];?>"></td>
			</tr>
			<tr>
				<td><label for="gender">Gender:</label></td>

                <td>  
                <?php
                if($d['gender'] == 1){
    
                                ?>
                    
                        <input type="radio" name="gender" value="1" checked > Laki-laki
                        <input type="radio" name="gender" value="2"> Perempuan
                        <?php }else{ ?>
                        <input type="radio" name="gender" value="1" > Laki-laki
                        <input type="radio" name="gender" value="2" checked> Perempuan
                            
                        <?php } ?>
                </td>
			</tr>
			<tr>
				<td><label for="ukm">UKM yang Dipilih:</label></td>
				<td>
					<select id="ukm" name="ukm" value="<?= $d["ukm"];?>">
						<option value="Paskibra">Paskibra</option>
						<option value="PMR">PMR</option>
						<option value="Basket">Basket</option>
						<option value="Voli">Voli</option>
					</select>
				</td>
			</tr>
			<tr>
				<td><label for="keahlian">Keahlian yang Dikuasai:</label></td>
				<td><input type="text" id="keahlian" name="keahlian" value="<?= $d["keahlian"];?>"></td>
			</tr>
			<tr>
				<td><label for="no_hp">No HP:</label></td>
				<td><input type="text" id="no_hp" name="no_hp" value="<?= $d["no_hp"];?>"></td>
			</tr>
			<tr>
				<td><label for="email">Email:</label></td>
				<td><input type="email" id="email" name="email" value="<?= $d["email"];?>"></td>
			</tr>
		</table>
		<input type="submit" name="submit" value="Simpan">
	</form>

    <?php
        }
        ?>
</body>
</html>