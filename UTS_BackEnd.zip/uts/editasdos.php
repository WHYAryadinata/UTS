<?php 
    include 'configasdos.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTS</title>
</head>
<style>
</style>
<body>
    <?php 
        $nim = $_GET['nim'];
        $data = mysqli_query($conn,"SELECT * FROM asdos WHERE nim = '$nim' ");
        while($d = mysqli_fetch_assoc($data)){
        ?> 
        	<form method="POST" action="updateasdos.php">
			<table>
            <tr>
                <td>Nama:</td>
                <td><input type="text" name="nama"value="<?= $d["nama"];?>"></td>
            </tr>
            <tr>
                <td>NIM:</td>
                <td><input type="text" name="nim"value="<?= $d["nim"];?>"></td>
            </tr>
            <tr>
                    <td>Jurusan</td>
                    <td><select name="jurusan"value="<?= $d["jurusan"];?>">
                        <option value="001">Sistem Komputer</option>
                        <option value="002">Sistem Informasi</option>
                        <option value="003">Teknologi Informasi</option>
                    </select></td>
                </tr>
            <tr>
                <td>Angkatan:</td>
                <td><input type="text" name="angkatan"value="<?= $d["angkatan"];?>"></td>
            </tr>
            <tr>
                <td>Gender:</td>
                <td>
                    <input type="radio" name="gender" value="1">Laki-laki<br>
                    <input type="radio" name="gender" value="2">Perempuan<br>
                </td>
            </tr>
            <tr>
                <td>Dosen yang ingin di tuju:</td>
                <td><input type="text" name="dosen"value="<?= $d["dosen"];?>"></td>
            </tr>
            <tr>
                <td>Keahlian yang di kuasai:</td>
                <td><input type="text" name="keahlian"value="<?= $d["keahlian"];?>"></td>
            </tr>
            <tr>
                <td>No hp:</td>
                <td><input type="text" name="no_hp"value="<?= $d["no_hp"];?>"></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><input type="text" name="email"value="<?= $d["email"];?>"></td>
            </tr>
           <tr>
                    <td><input type="submit" value="Simpan"><input type="button" value="Kembali"></td>
                </tr>
        </table>
	</form>

    <?php
        }
        ?>
</body>
</html>