<?php

include 'configasdos.php';

$nim = $_GET ['nim'];
$sql = "DELETE FROM asdos where nim = '$nim'";
    if(mysqli_query($conn, $sql)){
        $message = "Data Berhasil dihapus";
        echo "<script type='text/javascript'>window.alert('$message'); window.location = 'asdos.php';</script>";
    }
    else{
        $message = "Data gagal Dihapus";
        echo "<script type='text/javascript'>window.alert('$message'); window.location = 'asdos.php';</script>";
    }
?>