<?php 

include 'configorganisasi.php';

$nama = $_POST ['nama'];
$nim = $_POST ['nim'];
$kd_jurusan = $_POST ['jurusan'];
$angkatan = $_POST ['angkatan'];
$gender = $_POST ['gender'];
$organisasi = $_POST ['organisasi'];
$keahlian = $_POST ['keahlian'];
$no_hp = $_POST ['no_hp'];
$email = $_POST ['email'];
$exec = mysqli_query($conn, "UPDATE organisasi set nama = '$nama', nim = '$nim', kd_jurusan = '$kd_jurusan', angkatan = '$angkatan', gender = '$gender', organisasi = '$organisasi', keahlian = '$keahlian', no_hp = '$no_hp', email = '$email' WHERE nim = '$nim' ");
if ($exec){
    $message = "Data Berhasil Dirubah";
    echo "<script type='text/javascript'>window.alert('$message'); window.location = 'organisasi.php';</script>";
}
else{
    echo"data gagal dirubah";
}
?>
 