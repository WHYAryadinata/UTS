<?php 

include 'configasdos.php';

$nama = $_POST ['nama'];
$nim = $_POST ['nim'];
$kd_jurusan = $_POST ['jurusan'];
$angkatan = $_POST ['angkatan'];
$gender = $_POST ['gender'];
$dosen = $_POST ['dosen'];
$keahlian = $_POST ['keahlian'];
$no_hp = $_POST ['no_hp'];
$email = $_POST ['email'];
$exec = mysqli_query($conn, "UPDATE asdos set nama = '$nama', nim = '$nim', kd_jurusan = '$kd_jurusan', angkatan = '$angkatan', gender = '$gender', dosen = '$dosen', keahlian = '$keahlian', no_hp = '$no_hp', email = '$email' WHERE nim = '$nim' ");
if ($exec){
    $message = "Data Berhasil Dirubah";
    echo "<script type='text/javascript'>window.alert('$message'); window.location = 'asdos.php';</script>";
}
else{
    echo"data gagal dirubah";
}
?>